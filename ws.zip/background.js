/* eslint-disable import/no-webpack-loader-syntax */
import * as JsStore from 'jsstore'
import wp from 'file-loader?name=scripts/[name].[hash].js!jsstore/dist/jsstore.worker.js' // Add .min to filename when in production mode

const connection = new JsStore.Connection(new Worker(wp))
connection.setLogStatus(true)
console.log('connection :>> ', connection)

browser.runtime.onMessage.addListener(handleMessage)
function handleMessage (request, sender, sendResponse) {
  console.log(request, sender, sendResponse) // logs "your message"
}

// browser.browserAction.onClicked.addListener(() => {
//   browser.tabs.executeScript({ file: 'content.js' })
// })
